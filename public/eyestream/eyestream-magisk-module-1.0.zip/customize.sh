#!/system/bin/sh
# Magisk module install script

ui_print "- Installing eyestream (Baballonia MJPEG bridge)"

# Check if eyed module is installed
if [ ! -d "/data/adb/modules/eyed" ]; then
    ui_print "! WARNING: eyed module not found"
    ui_print "! eyestream requires eyed to be installed first"
    ui_print ""
fi

# Set executable permissions
set_perm "$MODPATH/system/bin/eyestream" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755

ui_print "- eyestream binary installed to /system/bin (overlay)"
ui_print "- service.sh will start after eyed socket is ready"
ui_print ""
ui_print "- Endpoints (after reboot):"
ui_print "    http://<device-ip>:4442/left"
ui_print "    http://<device-ip>:4442/right"
ui_print "    http://<device-ip>:4442/mouth"
ui_print ""
