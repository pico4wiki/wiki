#!/system/bin/sh
# Placeholder - eyestream starts via service.sh after boot
