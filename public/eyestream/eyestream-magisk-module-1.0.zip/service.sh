#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot + eyed to be ready
sleep 15

# Wait for eyed socket to appear (depends on eyed module)
SOCK=/data/local/tmp/eyed.sock
while [ ! -S "$SOCK" ]; do
    sleep 2
done

# Supervisor loop: restart eyestream if it ever exits
while true; do
    if ! pidof eyestream >/dev/null 2>&1; then
        "$MODDIR/system/bin/eyestream" &
    fi
    sleep 5
done
