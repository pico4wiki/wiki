#!/system/bin/sh
# Magisk module install script

ui_print "- Installing eyed (Pico 4P/4E eye tracking daemon)"

# Set executable permissions
set_perm "$MODPATH/system/bin/eyed" 0 0 0755
set_perm "$MODPATH/system/bin/injector" 0 0 0755
set_perm "$MODPATH/system/bin/agent_frame.so" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755

ui_print "- Binaries installed to /system/bin (overlay)"
ui_print "- service.sh will supervise eyed and restart if it dies"
ui_print ""
