#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot to settle
sleep 10

# Supervisor loop: restart eyed if it ever exits
while true; do
    if ! pidof eyed >/dev/null 2>&1; then
        "$MODDIR/system/bin/eyed" &
    fi
    sleep 5
done
