#!/system/bin/sh
# Runs early in boot (before zygote). Nothing needed here for eyed.
