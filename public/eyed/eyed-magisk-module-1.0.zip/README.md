# eyed Magisk Module

Installs the eyed daemon (Pico 4P/E eye tracking camera feed) as a Magisk module.

## What it does

- Places `eyed`, `injector`, and `agent_frame.so` in `/system/bin` (via Magisk overlay)
- Provides `service.sh` that supervises eyed and restarts it if it dies

## Installation

Flash the zip via Magisk Manager or TWRP.
